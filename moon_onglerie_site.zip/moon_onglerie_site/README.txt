MOON ONGLERIE — SITE INTERNET

Fichiers
- index.html : page du site (responsive mobile/ordinateur).

Avant publication
1. Remplacer les trois images Unsplash dans index.html par les propres photos de Moon Onglerie. Chercher les URLs des images dans les attributs src des balises img. Pour une méthode simple, téléverser les photos dans le même dépôt GitHub et remplacer les URLs par des chemins comme images/pose-1.jpg.
2. Vérifier le lien de réservation Nailbookpro et le profil Instagram.
3. Vérifier que l’adresse affichée est bien celle que vous souhaitez rendre publique.
4. Ajouter les mentions légales et une politique de confidentialité si des données personnelles sont collectées. Ce site ne contient actuellement aucun formulaire.

Publication gratuite avec GitHub Pages
1. Créer/connecter un compte sur https://github.com/.
2. Créer un nouveau dépôt public nommé moon-onglerie-site.
3. Téléverser index.html à la racine du dépôt (et les photos dans un dossier images si vous remplacez les images externes).
4. Dans le dépôt : Settings > Pages. Dans Build and deployment, choisir Deploy from a branch, puis la branche main et le dossier /(root), puis Save.
5. Après le déploiement, GitHub affichera une adresse du type https://VOTRE-NOM.github.io/moon-onglerie-site/.
6. Pour utiliser un domaine personnalisé (par exemple moononglerie.fr, si disponible), acheter le domaine chez un registrar, puis renseigner le domaine dans Settings > Pages et suivre les instructions DNS affichées par GitHub. Attendre la propagation DNS et activer/vérifier HTTPS.

Le site n’est pas encore publié : il faut effectuer ces étapes dans vos propres comptes.
